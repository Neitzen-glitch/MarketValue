'use client';
import { useEffect } from 'react';
import { useCart } from './CartProvider';

// Empties the cart once an order is confirmed.
export default function ClearCart() {
  const { clear, ready } = useCart();
  useEffect(() => {
    if (ready) clear();
  }, [ready, clear]);
  return null;
}
